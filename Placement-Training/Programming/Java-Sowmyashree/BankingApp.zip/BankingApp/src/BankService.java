import java.util.*;

public class BankService {
    private List<Account> accounts;

    public BankService() {
        accounts = new ArrayList<>();
    }

    public void createAccount(String number, String holder) {
        Account acc = new Account(number, holder);
        accounts.add(acc);
    }

    public Account findAccount(String number) {
        for (Account acc : accounts) {
            if (acc.getAccountNumber() == number) { 
                return acc;
            }
        }
        return null;
    }

    public void printAllAccounts() {
        for (Account acc : accounts) {
            System.out.println(acc); 
        }
    }
}
