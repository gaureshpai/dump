import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        BankService service = new BankService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("1. Create Account\n2. Deposit\n3. Withdraw\n4. View All\n5. Exit");
            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.println("Enter Account Number:");
                String accNum = sc.next();

                System.out.println("Enter Account Holder Name:");
                String accHolder = sc.nextLine(); 

                service.createAccount(accNum, accHolder);
                System.out.println("Account created.");

            } else if (choice == 2) {
                System.out.println("Enter Account Number:");
                String accNum = sc.next();

                System.out.println("Enter Amount:");
                double amt = sc.nextDouble();

                Account acc = service.findAccount(accNum);
                acc.deposit(amt); 

            } else if (choice == 3) {
                System.out.println("Enter Account Number:");
                String accNum = sc.next();

                System.out.println("Enter Amount:");
                double amt = sc.nextDouble();

                Account acc = service.findAccount(accNum);
                acc.withdraw(amt); 

            } else if (choice == 4) {
                service.printAllAccounts();

            } else if (choice == 5) {
                break;
            }
        }

        sc.close();
    }
}
