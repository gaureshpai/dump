public class Account {
    private String accountNumber;
    private String accountHolder;
    private double balance;

    public Account(String number, String holder) {
        accountNumber = number;
        accountHolder = holder;
        balance = 0;
    }

    public void deposit(double amount) {
        balance += amount; 
    }

    public void withdraw(double amount) {
        balance -= amount; 
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    
}
