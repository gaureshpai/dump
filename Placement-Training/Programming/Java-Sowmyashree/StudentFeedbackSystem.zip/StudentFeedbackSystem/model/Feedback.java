package model;

public class Feedback {
    private Student student;
    private String message;

    public Feedback(Student student, String message) {
        this.student = student;
        this.message = message;
    }

    public Student getStudent() {
        return student;
    }

    public String getMessage() {
        return message;
    }
}