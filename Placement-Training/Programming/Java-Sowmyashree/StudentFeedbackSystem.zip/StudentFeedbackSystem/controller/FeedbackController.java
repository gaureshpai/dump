package controller;

import model.Feedback;
import model.Student;
import service.FeedbackService;

import java.util.Scanner;

public class FeedbackController {
    private FeedbackService service = FeedbackService.getInstance();
    private Scanner scanner = new Scanner(System.in);

    public void run() {
        System.out.println("Welcome to Student Feedback System");

        while (true) {
            System.out.println("\n1. Submit Feedback\n2. View Feedbacks\n3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();  

            switch (choice) {
                case 1:
                    System.out.print("Enter Student Name: ");
                    String name = scanner.nextLine(); 
                    System.out.print("Enter Feedback: ");
                    String fb = scanner.nextLine();

                    Student student = new Student(name);
                    Feedback feedback = new Feedback(student, fb);
                    service.saveFeedback(feedback);
                    System.out.println("Feedback submitted.");
                    break;
                case 2:
                    service.printFeedbacks();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}