import controller.FeedbackController;

public class Main {
    public static void main(String[] args) {
        FeedbackController controller = new FeedbackController();
        controller.run();
    }
}