package service;

import model.Feedback;

import java.util.ArrayList;
import java.util.List;

public class FeedbackService {
    private static FeedbackService instance;
    private List<Feedback> feedbacks; 

    private FeedbackService() {}

    public static FeedbackService getInstance() {
        if (instance == null) {
            instance = new FeedbackService();
        }
        return instance;
    }

    public void saveFeedback(Feedback feedback) {
        feedbacks.add(feedback); 
    }

    public void printFeedbacks() {
        if (feedbacks.isEmpty()) {
            System.out.println("No feedback submitted.");
            return;
        }
        for (Feedback fb : feedbacks) {
            System.out.println(fb.getStudent().getName() + ": " + fb.getMessage());
        }
    }
}